<?php 

class View extends controller{

    

}